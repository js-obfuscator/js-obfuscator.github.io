var bytenode = require("./bytenode.js");
bytenode.runBytecodeFile('./core.jsc');