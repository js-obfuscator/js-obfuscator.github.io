# JS-Obfuscator 本地JS混淆
官网：https://www.js-obfuscator.com

# 简介
JS-Obfuscator.com的本地JS混淆工具，功能特点：
1.1、用于在本机完成JS文件混淆，代码不传至JS-Obfuscator服务器，不经过互联网，更安全、更私密；
1.2、被混淆JS文件不限体积大小、不限数量，一键完成多文件混淆。
1.3、Node.JS版本要求：v12.22.4

# 使用方法
1、执行JS混淆
在命令行中当前目录下使用Node.JS启动JS-Obfuscator进行JS文件混淆，命令：Node JS-Obfuscator，或双击运行js-obfuscator.bat；
执行此命令，即可将配置中的JS文件混淆完毕。

2、配置
在进行JS混淆前，特别是首次使用时，需修改配置文件config.json中的参数：
2.1、"secret_key"：JS-Obfuscator密钥，需在JS-Obfuscator.com购买获得，在此配置后，进行JS混淆加密时，虽代码在本地进行JS混淆，但混淆时需验证密钥。
提示：会向JS-Obfuscator服务器验证此密钥，但不会传递JS代码，JS代码混淆是在本地完成。
2.2、"source_folder"：JS混淆原目录，请将要混淆的JS文件放置在此目录下（可包含子目录）。
2.3、"target_folder"：JS混淆结果目录（会保持与源目录同样的结构，如：文件、子目录）。
2.4、混淆参数说明：
2.4.1、"part_variable_identifier_obfuscate"：重命名私有标识符
例如，混淆之前：
function demo(){
    var age=99;
}
混淆之后：
function demo(){
    var _0xk$r=99;
}
2.4.2、"global_variable_identifier_obfuscate"：重命名全局标识符
例如，混淆之前：
var age=99;
function demo(){
    var age = 99;
}
混淆之后：
var _0xk$r=99;
function demo(){
    var age = 99;
}
2.4.3、"part_function_identifier_obfuscate"：重命名私有函数
例如，混淆之前：
function demo(){
    var age = 99;
    function demo_sub(){
    }
}
混淆之后：
function demo(){
    var age = 99;
    function _0x62a87c(){
    }
}
2.4.4、"global_function_identifier_obfuscate"：重命名全局函数
例如，混淆之前：
function demo(){
    var age = 99;
    function demo_sub(){
    }
}
混淆之后：
function _0x62ab7d(){
    var age = 99;
    function demo_sub(){
    }
}
2.4.5、"member_expression_encode"：属性访问加密
例如，混淆之前：
console.log("demo");
混淆之后：
console['\x6c\x6f\x67']("demo"); 
2.4.6、"numberic_literal_encode"：数字转表达式
例如，混淆之前：
var num = 123;
混淆之后：
var num = 683517 ^ 683398;
2.4.7、"binary_express_obfuscate"：表达式转函数
例如，混淆之前：
var num = 683517 ^ 683398;
混淆之后：
var num = function (s, h) {
    return s ^ h;
}(683517, 683398);
2.4.8、"boolean_encode"：布尔值加密
例如，混淆之前：
var done = true;
混淆之后：
var done = !![];
2.4.9、"json_encode"：JSON数据加密。注意：需要同时启用"字符串数组化"和"字符串数组加密"选项
例如，混淆之前：
var man = {"name":"tim","age":18};
混淆之后：
var _0xeb6d9b=["114.3.41.41.43.103.104.100.108.43.51.41.43.125.96.100.43.37.3.41.41.43.104.110.108.43.51.41.56.49.3.116."];function _0xf72b(str,dy_key){dy_key=9;var i,k,str2="";k=str.split(".");for(i=0;i<k.length-1;i++){str2+=String.fromCharCode(k[i]^dy_key);}return str2;}var man=JSON.parse(_0xf72b(_0xeb6d9b[0]));
2.4.10、"string_unicode_encode"：字符串Unicode编码化
例如，混淆之前：
var obf = "JS-Obfuscator";
混淆之后：
var obf = "\u004a\u0053\u002d\u004f\u0062\u0066\u0075\u0073\u0063\u0061\u0074\u006f\u0072";
2.4.11、"assignment_junk_code"：赋值转函数
例如，混淆之前：
var name;
name = "jack";
混淆之后：
var name;
name = function () {
    return "jack";
}();
2.4.12、"zombie_code"：僵尸代码植入
例如，混淆之前：
var a=1;
var b=2;
混淆之后：
var _0x;
var a = 1;
_0x = "jfci";
var b = 2;
2.4.13、"eval_encode"：Eval加密
例如， 混淆之前：
var a = 1 + 2;
混淆之后：
var a = eval(String.fromCharCode(49, 32, 43, 32, 50));
2.4.14、"control_flow"：控制流扁平化
例如，混淆之前：
function demo(){
    var name = "tom";
    var age = "18";
    return name + age;
}
混淆之后：
function demo() {
    var _array = "1|0|2".split("|"),
    _index = 0;
    while (!![]) {
        switch (+_array[_index++]) {
        case 0:
            var age = "18";
            continue;
        case 1:
            var name = "tom";
            continue;
        case 2:
            return name + age;
            continue;
        }
        break;
    }
}
2.4.15、"string_reverse"：字符串反转
例如，混淆之前：
var name = "tom";
混淆之后：
var name = "mot".split("").reverse().join("");
2.4.16、"comma_operator"：控制流收缩
例如，混淆之前：
function demo(){
    var name = "tom";
    var age = "18";
    return name + age;
}
混淆之后：
function demo(name, age) {
    return age = (name = "tom", "18"), name + age;
}
2.4.17、"class_encode"：类方法、属性加密
例如，混淆之前：
class Example {
    value = 1;
    method() {
    return this.value;
    }
}
new Example().method();
混淆之后：
class Example {
    \u0076\u0061\u006c\u0075\u0065 = 1;
    \u006d\u0065\u0074\u0068\u006f\u0064() {
    return this.value;
    }
}
new Example().method();
2.4.18、"private_variable_to_Param"：局部变量转函数参数
混淆之前：
function demo(){
    let v1 = 1;
    var v2 = 2;
    const v3 = 3;
}
混淆之后：
function demo(v1，v3) {
    v1 = 1;
    var v2 = 2;
    v3 = 3;
}
2.4.19、"string_array"：字符串数组化
例如，混淆之前：
function demo(){
    var name = "tom";
    var age = "18";
    return name + age;
}
混淆之后：
var _0x312g = ["tom", "18"];
function demo() {
    var name = _0x312g[0];
    var age = _0x312g[1];
    return name + age;
} 
2.4.20、"string_array_encode"：字符串数组加密
例如，混淆之前：
function demo(){
    var name = "tom";
    var age = "18";
    return name + age;
}
混淆之后：
var _0x=['125.102.100.','56.49.'];
function _0xa5bdc(str,dy_key){dy_key=9;var i,k,str2='';k=str.split('.');for(i=0;i<k.length-1;i++){str2+=String.fromCharCode(k[i]^dy_key);}return str2;}
function demo() {
    var name = _0xa5bdc(_0x[0]);
    var age = _0xa5bdc(_0x[1]);
    return name + age;
} 
2.4.21、"vm_execute"：VM执行
例如，混淆之前：
var num = 1+2;
混淆之后：
function _0xbd18dc(vm_opcode){var op={push:32,add:33,sub:34,mul:35,div:36,pop:37,xor:38};var stack=[];var ip=-1;var sp=-1;while(ip<vm_opcode.length){ip++;switch(vm_opcode[ip]){case op.push:{ip++;stack.push(vm_opcode[ip]);sp++;break;}case op.add:{var op_1=stack[sp-1];var op_2=stack[sp];var value=op_1+op_2;stack.push(value);sp++;break;}case op.sub:{var op_1=stack[sp-1];var op_2=stack[sp];var value=op_1-op_2;stack.push(value);sp++;break;}case op.mul:{var op_1=stack[sp-1];var op_2=stack[sp];var value=op_1*op_2;stack.push(value);sp++;break;}case op.div:{var op_1=stack[sp-1];var op_2=stack[sp];var value=op_1/op_2;stack.push(value);sp++;break;}case op.xor:{var op_1=stack[sp-1];var op_2=stack[sp];var value=op_1^op_2;stack.push(value);sp++;break;}case op.pop:{return stack[sp];}}}}var num=_0xbd18dc([32,1,32,2,33,37]);
2.4.22、"ast_execute"：AST执行
例如，混淆之前：
console.log("hello");
混淆之后：
var visitors={File(node,scope){ast_excute(node.program,scope);},Program(program,scope){for(i=0;i<program.body.length;i++){ast_excute(program.body[i],scope);}},ExpressionStatement(node,scope){return ast_excute(node.expression,scope);},CallExpression(node,scope){var func=ast_excute(node.callee,scope);var args=node.arguments.map(function(arg){return ast_excute(arg,scope);});var value;if(node.callee.type==='MemberExpression'){value=ast_excute(node.callee.object,scope);}return func.apply(value,args);},MemberExpression(node,scope){var obj=ast_excute(node.object,scope);var name=node.property.name;return obj[name];},Identifier(node,scope){return scope[node.name];},StringLiteral(node){return node.value;},NumericLiteral(node){return node.value;}};function ast_excute(node,scope){var evalute=visitors[node.type];if(!evalute){throw new Error("Unknown AST type:",node.type);}return evalute(node,scope);}ast_excute({"type":"CallExpression","callee":{"type":"MemberExpression","object":{"type":"Identifier","name":"console"},"property":{"type":"Identifier","name":"log"}},"arguments":[{"type":"StringLiteral","value":"hello"}]},{console:console});;
2.4.23、"regexp_encode"：正则表达式加密
2.4.24、"comments"：保留注释
2.4.25、"compress"：压缩代码
"reserved_word"：保留关键字。对指定的字符串、函数名和变量名不进行混淆处理。
"anti_beautify"：反美化。混淆后的JS代码如果被美化或格式化，代码将不能正确执行。提示：使用此选项时，“压缩代码”功能也需启用，否则混淆后的代码无法正常执行。
"anti_debug"：反调试。在代码中添加反调试器语句，防止代码被动态调试。
"start_day_limit"：开始日期限定。限制混淆后的代码只能在指定日期之后才能执行。 
"start_day"：开始日期限定值，如："2026-08-17"。
"end_day_limit"： 结束日期限定。限制混淆后的代码只能在指定日期之前才能执行行。
"end_day"：结束日期限定值，如："2026-08-17",
"platform_lock"：系统锁定。限制混淆后的代码只能在指定的系统中执行。注：仅适用于Node.JS。
"platforms"：系统锁定值，例如：linux、win32、darwin、android、ios。
"browser_lock"：浏览器锁定。限制混淆后的代码只能在指定的浏览器中执行。注：仅适用于浏览器。
"browsers"：浏览器锁定值，例如：chrome、firefox、safari、edge。
"anti_ai"：反AI。抵御ChatGPT和DeepSeek等AI工具，防止混淆后的代码被AI分析和反混淆。提示：支持Web浏览器、Node.JS两种运行环境下的JS代码。 
"anti_ai_environment"：反AI的代码环境设定，启用域名锁定设置值为："browser"，启用锁定主机名则设置值为：“hostname”。
"anti_ai_domain_to_lock"：域名锁定。使用网站域名作为密钥对代码进行加密，加密后的代码仅能在该域名下运行。请输入域名，不要包含 https:// 和 URL 路径，如："js-obfuscator.com"。
"anti_ai_hostname_to_lock"：锁定主机名。使用主机名作为密钥对代码进行加密，加密后的代码只能在具有该主机名的系统上运行。主机名指当前操作系统中配置的主机名，在 Linux/macOS 上：等同于执行 hostname 命令所获取的值，通常为系统安装时设置的名称；在 Windows 上，获取计算机的完整主机名或 NetBIOS 名称。你可以在 Node.js 命令行中使用代码 console.log(require('os').hostname()); 来获取确切的主机名。
"anti_ai_no_hostname":隐藏解密密钥特征。解密代码时使用域名或主机名做为解密密钥，加密此密钥，为防止此特征被洞察。隐藏：window.location.hostname（锁定域名特征） 或 require('os').hostname()（锁定主机特征）。 
"anti_ai_no_eval"：加密eval关键字。加密代码最终会用eval执行，加密eval关键字，进一步提升加密效果。将eval关键字加密为："lave".split("").reverse().join("") 或 (14).toString(32)+(31).toString(32)+(10).toString(32)+(21).toString(32) 等。

# 其它
1、如果混淆过程出现错误，例如被混淆的JS代码本身含有错误，出错的文件代码不会被混淆，文件会与其它混淆过的JS文件一起输出在目标位置。
2、如有任何其它问题，请向官网JS-Obfuscator.com联系。