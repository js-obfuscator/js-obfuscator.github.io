Introduction

JS-Obfuscator.com's local JS obfuscation tool features:
1.1. Perform JS file obfuscation entirely on your local machine. Code is never transmitted to JS-Obfuscator servers, never goes over the internet, making it more secure and private.
1.2. No limits on file size or number of JS files. One-click obfuscation for multiple files.
1.3. Node.js version requirement: v12.22.4
Usage Instructions

Run JS Obfuscation
In the command line, navigate to the current directory and use Node.js to start JS-Obfuscator with the command: Node JS-Obfuscator, or double-click to run js-obfuscator.bat.
Executing this command will obfuscate all JS files configured in the configuration file.

2. Configuration
Before performing JS obfuscation, especially for the first time, you need to modify the parameters in the configuration file config.json:

2.1. "secret_key": The JS-Obfuscator license key, which must be purchased from JS-Obfuscator.com. After configuration, the key will be verified during obfuscation, although the obfuscation itself is performed locally.
Note: The key is validated against the JS-Obfuscator server, but no JS code is transmitted. The obfuscation process is completed locally.

2.2. "source_folder": The source directory for JS obfuscation. Place all JS files to be obfuscated in this directory (subdirectories are supported).

2.3. "target_folder": The output directory for obfuscated JS files (the directory structure, including files and subdirectories, will be preserved).

2.4. Obfuscation Parameter Descriptions:

2.4.1. "part_variable_identifier_obfuscate": Rename private identifiers
Example before obfuscation:
function demo(){
    var age=99;
}
After obfuscation:
function demo(){
    var _0xk$r=99;
}

2.4.2. "global_variable_identifier_obfuscate": Rename global identifiers
Example before obfuscation:
var age=99;
function demo(){
    var age = 99;
}
After obfuscation:
var _0xk$r=99;
function demo(){
    var age = 99;
}

2.4.3. "part_function_identifier_obfuscate": Rename private functions
Example before obfuscation:
function demo(){
    var age = 99;
    function demo_sub(){
    }
}
After obfuscation:
function demo(){
    var age = 99;
    function _0x62a87c(){
    }
}

2.4.4. "global_function_identifier_obfuscate": Rename global functions
Example before obfuscation:
function demo(){
    var age = 99;
    function demo_sub(){
    }
}
After obfuscation:
function _0x62ab7d(){
    var age = 99;
    function demo_sub(){
    }
}

2.4.5. "member_expression_encode": Encrypt property access
Example before obfuscation:
console.log("demo");
After obfuscation:
console['\x6c\x6f\x67']("demo");

2.4.6. "numeric_literal_encode": Convert numbers to expressions
Example before obfuscation:
var num = 123;
After obfuscation:
var num = 683517 ^ 683398;

2.4.7. "binary_express_obfuscate": Convert expressions to functions
Example before obfuscation:
var num = 683517 ^ 683398;
After obfuscation:
var num = function (s, h) {
    return s ^ h;
}(683517, 683398);

2.4.8. "boolean_encode": Encrypt boolean values
Example before obfuscation:
var done = true;
After obfuscation:
var done = !![];

2.4.9. "json_encode": Encrypt JSON data. Note: Requires enabling both "string array" and "string array encryption" options.
Example before obfuscation:
var man = {"name":"tim","age":18};
After obfuscation:
var _0xeb6d9b=["114.3.41.41.43.103.104.100.108.43.51.41.43.125.96.100.43.37.3.41.41.43.104.110.108.43.51.41.56.49.3.116."];function _0xf72b(str,dy_key){dy_key=9;var i,k,str2="";k=str.split(".");for(i=0;i<k.length-1;i++){str2+=String.fromCharCode(k[i]^dy_key);}return str2;}var man=JSON.parse(_0xf72b(_0xeb6d9b[0]));

2.4.10. "string_unicode_encode": Encode strings as Unicode
Example before obfuscation:
var obf = "JS-Obfuscator";
After obfuscation:
var obf = "\u004a\u0053\u002d\u004f\u0062\u0066\u0075\u0073\u0063\u0061\u0074\u006f\u0072";

2.4.11. "assignment_junk_code": Convert assignments to functions
Example before obfuscation:
var name;
name = "jack";
After obfuscation:
var name;
name = function () {
    return "jack";
}();

2.4.12. "zombie_code": Inject zombie code
Example before obfuscation:
var a=1;
var b=2;
After obfuscation:
var _0x;
var a = 1;
_0x = "jfci";
var b = 2;

2.4.13. "eval_encode": Eval encryption
Example before obfuscation:
var a = 1 + 2;
After obfuscation:
var a = eval(String.fromCharCode(49, 32, 43, 32, 50));

2.4.14. "control_flow": Control flow flattening
Example before obfuscation:
function demo(){
    var name = "tom";
    var age = "18";
    return name + age;
}
After obfuscation:
function demo() {
    var _array = "1|0|2".split("|"),
    _index = 0;
    while (!![]) {
        switch (+_array[_index++]) {
        case 0:
            var age = "18";
            continue;
        case 1:
            var name = "tom";
            continue;
        case 2:
            return name + age;
            continue;
        }
        break;
    }
}

2.4.15. "string_reverse": Reverse strings
Example before obfuscation:
var name = "tom";
After obfuscation:
var name = "mot".split("").reverse().join("");

2.4.16. "comma_operator": Control flow contraction
Example before obfuscation:
function demo(){
    var name = "tom";
    var age = "18";
    return name + age;
}
After obfuscation:
function demo(name, age) {
    return age = (name = "tom", "18"), name + age;
}

2.4.17. "class_encode": Encrypt class methods and properties
Example before obfuscation:
class Example {
    value = 1;
    method() {
    return this.value;
    }
}
new Example().method();
After obfuscation:
class Example {
    \u0076\u0061\u006c\u0075\u0065 = 1;
    \u006d\u0065\u0074\u0068\u006f\u0064() {
    return this.value;
    }
}
new Example().method();

2.4.18. "private_variable_to_Param": Convert local variables to function parameters
Example before obfuscation:
function demo(){
    let v1 = 1;
    var v2 = 2;
    const v3 = 3;
}
After obfuscation:
function demo(v1, v3) {
    v1 = 1;
    var v2 = 2;
    v3 = 3;
}

2.4.19. "string_array": Convert strings to array
Example before obfuscation:
function demo(){
    var name = "tom";
    var age = "18";
    return name + age;
}
After obfuscation:
var _0x312g = ["tom", "18"];
function demo() {
    var name = _0x312g[0];
    var age = _0x312g[1];
    return name + age;
}

2.4.20. "string_array_encode": Encrypt string arrays
Example before obfuscation:
function demo(){
    var name = "tom";
    var age = "18";
    return name + age;
}
After obfuscation:
var _0x=['125.102.100.','56.49.'];
function _0xa5bdc(str,dy_key){dy_key=9;var i,k,str2='';k=str.split('.');for(i=0;i<k.length-1;i++){str2+=String.fromCharCode(k[i]^dy_key);}return str2;}
function demo() {
    var name = _0xa5bdc(_0x[0]);
    var age = _0xa5bdc(_0x[1]);
    return name + age;
}

2.4.21. "vm_execute": VM execution
Example before obfuscation:
var num = 1+2;
After obfuscation:
function _0xbd18dc(vm_opcode){var op={push:32,add:33,sub:34,mul:35,div:36,pop:37,xor:38};var stack=[];var ip=-1;var sp=-1;while(ip<vm_opcode.length){ip++;switch(vm_opcode[ip]){case op.push:{ip++;stack.push(vm_opcode[ip]);sp++;break;}case op.add:{var op_1=stack[sp-1];var op_2=stack[sp];var value=op_1+op_2;stack.push(value);sp++;break;}case op.sub:{var op_1=stack[sp-1];var op_2=stack[sp];var value=op_1-op_2;stack.push(value);sp++;break;}case op.mul:{var op_1=stack[sp-1];var op_2=stack[sp];var value=op_1*op_2;stack.push(value);sp++;break;}case op.div:{var op_1=stack[sp-1];var op_2=stack[sp];var value=op_1/op_2;stack.push(value);sp++;break;}case op.xor:{var op_1=stack[sp-1];var op_2=stack[sp];var value=op_1^op_2;stack.push(value);sp++;break;}case op.pop:{return stack[sp];}}}}var num=_0xbd18dc([32,1,32,2,33,37]);

2.4.22. "ast_execute": AST execution
Example before obfuscation:
console.log("hello");
After obfuscation:
var visitors={File(node,scope){ast_excute(node.program,scope);},Program(program,scope){for(i=0;i<program.body.length;i++){ast_excute(program.body[i],scope);}},ExpressionStatement(node,scope){return ast_excute(node.expression,scope);},CallExpression(node,scope){var func=ast_excute(node.callee,scope);var args=node.arguments.map(function(arg){return ast_excute(arg,scope);});var value;if(node.callee.type==='MemberExpression'){value=ast_excute(node.callee.object,scope);}return func.apply(value,args);},MemberExpression(node,scope){var obj=ast_excute(node.object,scope);var name=node.property.name;return obj[name];},Identifier(node,scope){return scope[node.name];},StringLiteral(node){return node.value;},NumericLiteral(node){return node.value;}};function ast_excute(node,scope){var evalute=visitors[node.type];if(!evalute){throw new Error("Unknown AST type:",node.type);}return evalute(node,scope);}ast_excute({"type":"CallExpression","callee":{"type":"MemberExpression","object":{"type":"Identifier","name":"console"},"property":{"type":"Identifier","name":"log"}},"arguments":[{"type":"StringLiteral","value":"hello"}]},{console:console});;

2.4.23. "regexp_encode": Encrypt regular expressions

2.4.24. "comments": Preserve comments

2.4.25. "compress": Compress code

"reserved_word": Reserved keywords. Specified strings, function names, and variable names will not be obfuscated.

"anti_beautify": Anti-beautification. If the obfuscated JS code is beautified or formatted, it will not execute correctly. Note: When using this option, the "compress code" feature must also be enabled; otherwise, the obfuscated code will not run properly.

"anti_debug": Anti-debugging. Adds anti-debugger statements to the code to prevent dynamic debugging.

"start_day_limit": Start date restriction. Limits the obfuscated code to execute only after a specified date.

"start_day": Start date value, e.g., "2026-08-17".

"end_day_limit": End date restriction. Limits the obfuscated code to execute only before a specified date.

"end_day": End date value, e.g., "2026-08-17".

"platform_lock": Platform locking. Restricts the obfuscated code to run only on specified systems. Note: Only applicable to Node.js.

"platforms": Platform values, e.g., linux, win32, darwin, android, ios.

"browser_lock": Browser locking. Restricts the obfuscated code to run only in specified browsers. Note: Only applicable to browsers.

"browsers": Browser values, e.g., chrome, firefox, safari, edge.

"anti_ai": Anti-AI. Protects against AI tools such as ChatGPT and DeepSeek, preventing the obfuscated code from being analyzed and deobfuscated by AI. Note: Supports both web browser and Node.js environments.

"anti_ai_environment": Anti-AI environment setting. Set to "browser" for domain locking, or "hostname" for hostname locking.

"anti_ai_domain_to_lock": Domain locking. Uses a website domain as the key to encrypt the code, so the encrypted code can only run under that domain. Enter the domain without https:// or URL paths, e.g., "js-obfuscator.com".

"anti_ai_hostname_to_lock": Hostname locking. Uses the hostname as the key to encrypt the code, so the encrypted code can only run on systems with that hostname. The hostname refers to the system's configured hostname. On Linux/macOS, it is the value obtained by the hostname command (usually the name set during installation). On Windows, it is the full computer name or NetBIOS name. You can obtain the exact hostname in Node.js with console.log(require('os').hostname());.

"anti_ai_no_hostname": Hide decryption key characteristics. Since the domain or hostname is used as the decryption key, this option encrypts that key to prevent detection. It hides window.location.hostname (domain locking) or require('os').hostname() (hostname locking).

"anti_ai_no_eval": Encrypt the eval keyword. The final encrypted code uses eval for execution; this option encrypts the eval keyword itself for enhanced protection. The eval keyword is encrypted as, for example, "lave".split("").reverse().join("") or (14).toString(32)+(31).toString(32)+(10).toString(32)+(21).toString(32), etc.

Miscellaneous
1. If an error occurs during obfuscation (e.g., the JS code itself contains errors), the problematic file will not be obfuscated, but it will still be output to the target location along with the other successfully obfuscated files.
2. For any other issues, please contact the official website at JS-Obfuscator.com.