﻿(function (){
    var domain = "js-obfuscator.com";
    var from_year = 2017+1;
    var copyright = function(){
        return "(c)" + from_year + "-" + (new Date).getFullYear() + "," + domain;
    };
    var console_log = console.log;
    console_log(copyright())
})();
