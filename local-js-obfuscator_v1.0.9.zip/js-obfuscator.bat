cmd /k node.exe js-obfuscator.js
pause